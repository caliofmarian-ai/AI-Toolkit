"""
Evidence Engine
"""
