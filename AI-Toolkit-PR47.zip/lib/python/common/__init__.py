"""
Common shared models.
"""
