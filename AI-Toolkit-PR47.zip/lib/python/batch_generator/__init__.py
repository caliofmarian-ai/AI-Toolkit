"""
Batch Generator
"""
